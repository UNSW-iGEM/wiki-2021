%% Glutathione Peroxide (Gpx)
% k1_Gpx=[
%     45 NaN 8 1;
%     15 NaN 4 1; 
%     41 NaN 8 1; 
%     50 NaN 8 1; 
%     40 NaN 4 1; 
% ];
% [k1_Gpx_Mode, k1_Gpx_Spread] = CalcModeSpread(k1_Gpx);
% % [k1_Gpx_mu, k1_Gpx_sigma] = CreateLogNormDist(k1_Gpx_Mode, k1_Gpx_Spread); 
% 
% k2_Gpx=[
%     0.2 NaN 8 1;
%     0.2 NaN 4 1; 
%     0.23 NaN 8 1; 
%     0.79 NaN 4 1; 
% ];
% [k2_Gpx_Mode, k2_Gpx_Spread] = CalcModeSpread(k2_Gpx);
% % [k2_Gpx_mu, k2_Gpx_sigma] = CreateLogNormDist(k2_Gpx_Mode, k2_Gpx_Spread); 


% Michaelis Menten
Km_Gpx_GSH=[
    3200 NaN 16 1;
    316 NaN 8 1; 
    3700 NaN 32 1; 
    2100 NaN 8 1; 
];
[Km_Gpx_GSH_Mode, Km_Gpx_GSH_Spread] = CalcModeSpread(Km_Gpx_GSH);
% [Km_Gpx_GSH_mu, Km_Gpx_GSH_sigma] = CreateLogNormDist(Km_Gpx_GSH_Mode, Km_Gpx_GSH_Spread); 

Km_Gpx_H2O2=[
    3 NaN 8 1;
    12 NaN 8 1; 
    141 NaN 8 1; 
    170 NaN 4 1; 
    2.29 NaN 8 1; 
    240 NaN 32 1; 
    260 NaN 4 1; 
    204 NaN 32 1; 
];
[Km_Gpx_H2O2_Mode, Km_Gpx_H2O2_Spread] = CalcModeSpread(Km_Gpx_H2O2);
% [Km_Gpx_H2O2_mu, Km_Gpx_H2O2_sigma] = CreateLogNormDist(Km_Gpx_H2O2_Mode, Km_Gpx_H2O2_Spread); 

Kcat_Gpx=[
    44.03 NaN 4 1;
    670 NaN 8 1;
    221.7 NaN 8 1; 
];
[Kcat_Gpx_Mode, Kcat_Gpx_Spread] = CalcModeSpread(Kcat_Gpx);
[Kcat_Gpx_mu, Kcat_Gpx_sigma] = CreateLogNormDist(Kcat_Gpx_Mode, Kcat_Gpx_Spread); 

% Glutathione Reductase (GR)
Km_GR_GSSG=[
    50 NaN 32 1;
    54 NaN 16 1; 
    54 NaN 16 1; 
    55 NaN 8 1; 
    74.6 NaN 8 1; 
    101 NaN 8 1; 
];
[Km_GR_GSSG_Mode, Km_GR_GSSG_Spread] = CalcModeSpread(Km_GR_GSSG);
% [Km_GR_GSSG_mu, Km_GR_GSSG_sigma] = CreateLogNormDist(Km_GR_GSSG_Mode, Km_GR_GSSG_Spread); 

Km_GR_NADPH=[
    5 NaN 8 1;
    9 NaN 4 1; 
    10.6 NaN 32 1; 
    7 NaN 32 1; 
    28 NaN 16 1; 
    3.8 NaN 8 1; 
];
[Km_GR_NADPH_Mode, Km_GR_NADPH_Spread] = CalcModeSpread(Km_GR_NADPH);
% [Km_GR_NADPH_mu, Km_GR_NADPH_sigma] = CreateLogNormDist(Km_GR_NADPH_Mode, Km_GR_NADPH_Spread); 

Kcat_GR=[
    317 NaN 1 16;
    50.14 NaN 1 8;
    463.3 NaN 1 2;
];
[Kcat_GR_Mode, Kcat_GR_Spread] = CalcModeSpread(Kcat_GR);
% [Kcat_GR_mu, Kcat_GR_sigma] = CreateLogNormDist(Kcat_GR_Mode, Kcat_GR_Spread);
